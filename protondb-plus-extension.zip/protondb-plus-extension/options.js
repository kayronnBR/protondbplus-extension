// Exportar
document.getElementById('exportBtn').addEventListener('click', () => {
  chrome.storage.local.get({ redirects: {} }, (data) => {
    const blob = new Blob([JSON.stringify(data.redirects, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `backup_protondb_plus.json`;
    a.click();
  });
});

// Importar
document.getElementById('importBtn').addEventListener('click', () => {
  document.getElementById('fileInput').click();
});

document.getElementById('fileInput').addEventListener('change', (event) => {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const data = JSON.parse(e.target.result);
      chrome.storage.local.set({ redirects: data }, () => {
        alert('Backup restaurado!');
      });
    } catch (err) { alert('Erro ao importar!'); }
  };
  reader.readAsText(file);
});

// Limpar tudo
document.getElementById('clearBtn').addEventListener('click', () => {
  if (confirm('Tem certeza que deseja apagar TODAS as regras?')) {
    chrome.storage.local.set({ redirects: {} }, () => {
      alert('Dados apagados.');
    });
  }
});
