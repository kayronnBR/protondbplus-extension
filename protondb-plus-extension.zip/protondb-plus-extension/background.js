chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Detecta quando a URL de busca do ProtonDB é acessada
  if (changeInfo.url && changeInfo.url.includes("protondb.com/search?q=")) {
    
    try {
      const url = new URL(changeInfo.url);
      const searchQuery = decodeURIComponent(url.searchParams.get('q')).toLowerCase().trim();

      if (searchQuery) {
        chrome.storage.local.get({ redirects: {} }, (data) => {
          const redirects = data.redirects;

          // Se o nome pesquisado estiver na sua lista, redireciona
          if (redirects[searchQuery]) {
            const fileName = redirects[searchQuery];
            // URL fixa do seu blog conforme solicitado
            const targetUrl = `https://protondbplus.blogspot.com/2026/02/${fileName}.html`;
            
            chrome.tabs.update(tabId, { url: targetUrl });
          }
        });
      }
    } catch (e) {
      console.error("Erro no redirecionamento:", e);
    }
  }
});
