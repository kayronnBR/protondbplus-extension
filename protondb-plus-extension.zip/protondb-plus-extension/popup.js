// Salvar nova regra
document.getElementById('saveBtn').addEventListener('click', () => {
  const protonName = document.getElementById('protonName').value.toLowerCase().trim();
  const siteName = document.getElementById('siteName').value.trim();

  if (protonName && siteName) {
    chrome.storage.local.get({ redirects: {} }, (data) => {
      const redirects = data.redirects;
      redirects[protonName] = siteName;
      
      chrome.storage.local.set({ redirects }, () => {
        alert('Regra salva com sucesso!');
        document.getElementById('protonName').value = '';
        document.getElementById('siteName').value = '';
      });
    });
  } else {
    alert('Preencha ambos os campos!');
  }
});

// Exportar Backup
document.getElementById('exportBtn').addEventListener('click', () => {
  chrome.storage.local.get({ redirects: {} }, (data) => {
    const blob = new Blob([JSON.stringify(data.redirects, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `backup_protondb_plus.json`;
    a.click();
  });
});

// Importar Backup
document.getElementById('importBtn').addEventListener('click', () => {
  document.getElementById('fileInput').click();
});

document.getElementById('fileInput').addEventListener('change', (event) => {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const importedData = JSON.parse(e.target.result);
      chrome.storage.local.set({ redirects: importedData }, () => {
        alert('Backup restaurado com sucesso!');
        location.reload();
      });
    } catch (err) {
      alert('Arquivo inválido!');
    }
  };
  reader.readAsText(file);
});
