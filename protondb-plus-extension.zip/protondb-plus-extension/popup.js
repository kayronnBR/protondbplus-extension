document.getElementById('saveBtn').addEventListener('click', () => {
  const protonName = document.getElementById('protonName').value.toLowerCase().trim();
  const siteName = document.getElementById('siteName').value.trim();

  if (protonName && siteName) {
    chrome.storage.local.get({ redirects: {} }, (data) => {
      const redirects = data.redirects;
      redirects[protonName] = siteName;
      chrome.storage.local.set({ redirects }, () => {
        alert('Salvo!');
        document.getElementById('protonName').value = '';
        document.getElementById('siteName').value = '';
      });
    });
  }
});

// Abre a tela de opções (configurações)
document.getElementById('goSettings').addEventListener('click', () => {
  if (chrome.runtime.openOptionsPage) {
    chrome.runtime.openOptionsPage();
  } else {
    window.open(chrome.runtime.getURL('options.html'));
  }
});
